import 'package:flutter/material.dart';

import './screens/navigation_screen.dart';
import './screens/cart_screen.dart';
import './screens/filter_screen.dart';
import './screens/profile_screen.dart';
import './screens/notification_screen.dart';

import './screens/dress_details_screen.dart';

void main() => runApp(ShoeShop());

class ShoeShop extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        canvasColor: Color.fromRGBO(247, 247, 247, 1),
        secondaryHeaderColor: Color.fromRGBO(72, 164, 233, 1),
        accentColor: Color.fromRGBO(20, 25, 104, 1),
        textTheme: TextTheme(
          headline6: TextStyle(
            fontFamily: 'ReggaeOne',
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color.fromRGBO(20, 25, 130, 1),
          ),
          headline5: TextStyle(
            fontFamily: 'Righteous',
            fontSize: 20,
          ),
        ),
      ),
      title: 'ShoppyShop',
      // home: ShoeListScreen,
      routes: {
        '/': (ctx) => NavigationScreen(),
        CartScreen.routeName: (ctx) => CartScreen(),
        FilterScreen.routeNAme: (ctx) => FilterScreen(),
        ProfileScreen.routeName: (ctx) => ProfileScreen(),
        NotificationScreen.routeName: (ctx) => NotificationScreen(),
        DressDetailsScreen.routeName: (ctx) => DressDetailsScreen(),
      },
    );
  }
}
