import 'package:flutter/material.dart';

import '../dummy_data.dart';

import '../widgets/displayItems.dart';

class ShoeListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DisplayItems(wearings);
  }
}
