import 'package:flutter/material.dart';

import '../widgets/displayItems.dart';
import '../dummy_data.dart';

class FavouriteScreen extends StatelessWidget {
  static const routeName = '/FavouriteScreen';
  @override
  Widget build(BuildContext context) {
    return DisplayItems(favFolder);
  }
}
