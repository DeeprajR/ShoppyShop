import 'package:flutter/material.dart';

class FilterScreen extends StatelessWidget {
  static const routeNAme = 'FilterScree';
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
          margin: EdgeInsets.all(50),
          height: 150,
          width: 150,
          child: Image.network(
            'http://www.pngall.com/wp-content/uploads/2016/04/T-Shirt-Transparent.png',
            fit: BoxFit.fill,
          )),
    );
  }
}
