import 'package:flutter/material.dart';

import '../widgets/headline.dart';
import '../dummy_data.dart';
import '../widgets/fade_in_image.dart';
import '../widgets/sizes.dart';

import '../screens/cart_screen.dart';

class DressDetailsScreen extends StatefulWidget {
  static const routeName = '/DressDetailsScreen';

  @override
  _DressDetailsScreenState createState() => _DressDetailsScreenState();
}

class _DressDetailsScreenState extends State<DressDetailsScreen> {
  @override
  Widget build(BuildContext context) {
    Size medsize = MediaQuery.of(context).size;
    final route = ModalRoute.of(context);
    if (route == null) {
      return SizedBox.shrink();
    }
    final itemid = route.settings.arguments as String;

    final selectedItem = wearings.firstWhere((element) => element.id == itemid);
    addToFav(id) {
      setState(() {
        if (selectedItem.id == id) favFolder.add(selectedItem);
      });
    }

    removeFromFav(id) {
      setState(() {
        if (selectedItem.id == id) favFolder.remove(selectedItem);
      });
    }

    addToCart(id) {
      setState(() {
        if (selectedItem.id == id) myCart.add(selectedItem);
      });
    }

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.only(
                  top: 11, bottom: 11, left: 11, right: 11),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icon(Icons.arrow_back)),
                  Headline(),
                  Container(
                    height: 30,
                    width: 30,
                    child: favFolder.contains(selectedItem)
                        ? RawMaterialButton(
                            onPressed: () => removeFromFav(selectedItem.id),
                            child: Icon(
                              Icons.favorite,
                              color: Colors.red,
                              size: 22,
                            ),
                            shape: CircleBorder(),
                            elevation: 10,
                            fillColor: Colors.white,
                          )
                        : RawMaterialButton(
                            onPressed: () => addToFav(selectedItem.id),
                            child: Icon(
                              Icons.favorite,
                              color: Colors.white,
                              size: 22,
                            ),
                            shape: CircleBorder(),
                            elevation: 10,
                            fillColor: Colors.red,
                          ),
                  ),
                ],
              ),
            ),
            Stack(
              children: [
                Container(
                  decoration: BoxDecoration(boxShadow: [
                    BoxShadow(
                        blurRadius: 100,
                        color: Colors.black.withAlpha(50),
                        spreadRadius: 1)
                  ]),
                  padding: EdgeInsets.all(25),
                  margin: EdgeInsets.only(top: 20),
                  height: medsize.height * .47,
                  width: medsize.width * .88,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(15),
                    child: FadeInImae(
                      'assets/images/regiphy.gif',
                      selectedItem.imageUrl,
                    ),
                  ),
                ),
                if (selectedItem.isOfferAvilable == true)
                  Positioned(
                    top: 5,
                    right: 140,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: Theme.of(context)
                            .secondaryHeaderColor
                            .withOpacity(.5),
                      ),
                      height: medsize.height * .035,
                      width: medsize.width * .18,
                      child: Center(
                        child: Text(
                          '${selectedItem.offerPercentage ?? ''}%Off',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  )
              ],
            ),
            Stack(
              children: [
                Container(
                  height: medsize.height * .375,
                  width: medsize.width * 1,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(32),
                        topRight: Radius.circular(32)),
                    color: Color.fromRGBO(230, 230, 230, 1),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: EdgeInsets.only(top: 20, left: 15),
                            width: medsize.width * .84,
                            child: Text(
                              selectedItem.title ?? '',
                              overflow: TextOverflow.fade,
                              softWrap: true,
                              style: TextStyle(
                                  fontFamily: 'FredokaOne',
                                  fontSize: 22,
                                  color: Theme.of(context).accentColor),
                            ),
                          ),
                          Container(
                            margin: const EdgeInsets.only(right: 8),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.star,
                                  color: Colors.amber,
                                  size: 20,
                                ),
                                Text(
                                  '(${selectedItem.rating})',
                                  style: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 16,
                                  ),
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                      Sizes(selectedItem),
                      Container(
                        padding: EdgeInsets.all(15),
                        child: Text(
                          selectedItem.descrption ?? '',
                          style: TextStyle(
                              color: Colors.grey, fontFamily: 'Righteous'),
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  width: MediaQuery.of(context).size.width,
                  bottom: 0,
                  child: Container(
                    height: medsize.height * .11,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(32),
                        topRight: Radius.circular(32),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          margin: EdgeInsets.all(20),
                          child: Text(
                            '\$${selectedItem.price!.toStringAsFixed(2)}',
                            style: TextStyle(
                                fontFamily: 'FredokaOne',
                                fontWeight: FontWeight.bold,
                                fontSize: 25),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.all(20),
                          child: myCart.contains(selectedItem)
                              ? ElevatedButton.icon(
                                  onPressed: () {
                                    Navigator.of(context)
                                        .pushNamed(CartScreen.routeName);
                                  },
                                  icon: Icon(
                                    Icons.shopping_cart,
                                    color: Theme.of(context).accentColor,
                                  ),
                                  label: Text(
                                    'View Cart',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Theme.of(context).accentColor,
                                    ),
                                  ),
                                  style: ElevatedButton.styleFrom(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 15, vertical: 10),
                                    primary: Colors.grey.shade100,
                                    shadowColor: Colors.white,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(30)),
                                  ),
                                )
                              : ElevatedButton.icon(
                                  onPressed: () => addToCart(selectedItem.id),
                                  icon: Icon(
                                    Icons.shopping_cart,
                                    color: Theme.of(context).accentColor,
                                  ),
                                  label: Text(
                                    'Add to Cart',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Theme.of(context).accentColor,
                                    ),
                                  ),
                                  style: ElevatedButton.styleFrom(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 15, vertical: 10),
                                    primary: Colors.grey.shade100,
                                    shadowColor: Colors.white,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(30)),
                                  ),
                                ),
                        )
                      ],
                    ),
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
