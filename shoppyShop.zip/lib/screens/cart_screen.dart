import 'package:flutter/material.dart';

import '../dummy_data.dart';
import '../widgets/fade_in_image.dart';

class CartScreen extends StatefulWidget {
  static const routeName = '/cartScreen';

  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  double totl = 0;

  double total = myCart.fold(0, (previousValue, element) {
    return previousValue + (element.price as num);
  });
  deleteItem(id) {
    setState(() {
      myCart.removeWhere((element) => element.id == id);
    });
  }

  @override
  Widget build(BuildContext context) {
    Size meddata = MediaQuery.of(context).size;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.all(15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    icon: Icon(Icons.arrow_back),
                  ),
                  Text(
                    'My Cart',
                    style: TextStyle(
                      fontFamily: 'Righteous',
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    onPressed: () {},
                    icon: Icon(
                      Icons.shopping_cart,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
            Stack(
              children: [
                Container(
                  padding: EdgeInsets.all(15),
                  height: meddata.height * .861,
                  decoration: BoxDecoration(
                    color: Color.fromRGBO(225, 225, 225, 1),
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                  ),
                  child: ListView.builder(
                    itemCount: myCart.length,
                    itemBuilder: (ctx, index) {
                      return Card(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15)),
                        child: Container(
                          margin: EdgeInsets.all(5),
                          child: ListTile(
                            leading: FadeInImae(
                              'assets/images/giphy.gif',
                              myCart[index].imageUrl,
                            ),
                            title: Text(
                              myCart[index].title ?? '',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            subtitle: Container(
                              margin: EdgeInsets.all(10),
                              child: Text(
                                '\$${myCart[index].price}',
                                style: TextStyle(
                                    fontFamily: 'Righteous',
                                    fontSize: 20,
                                    color: Theme.of(context).accentColor),
                              ),
                            ),
                            trailing: IconButton(
                              onPressed: () => deleteItem(myCart[index].id),
                              icon: Icon(Icons.delete),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Positioned(
                  bottom: 0,
                  child: Container(
                      height: meddata.height * .13,
                      width: meddata.width * 1,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(32),
                            topRight: Radius.circular(32)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            margin: EdgeInsets.all(25),
                            child: Text(
                              '\$ $total',
                              style: TextStyle(
                                  fontFamily: 'FredokaOne',
                                  fontWeight: FontWeight.bold,
                                  fontSize: 25),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.all(20),
                            child: ElevatedButton.icon(
                              onPressed: () {},
                              icon: Icon(
                                Icons.exit_to_app,
                                size: 25,
                                color: Theme.of(context).secondaryHeaderColor,
                              ),
                              label: Text(
                                'Check Out',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Theme.of(context).secondaryHeaderColor,
                                ),
                              ),
                              style: ElevatedButton.styleFrom(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 15, vertical: 10),
                                primary: Theme.of(context).accentColor,
                                shadowColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30)),
                              ),
                            ),
                          ),
                        ],
                      )),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
