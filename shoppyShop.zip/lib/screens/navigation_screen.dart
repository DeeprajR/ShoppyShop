import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'dress_list_screen.dart';
import '../screens/favorite_screen.dart';
import '../screens/filter_screen.dart';
import '../screens/profile_screen.dart';
import '../screens/cart_screen.dart';

import '../widgets/top_bar.dart';
import '../widgets/bottom_app_bar.dart';
import '../widgets/drawer_widget.dart';
import '../dummy_data.dart';

class NavigationScreen extends StatefulWidget {
  @override
  _NavigationScreenState createState() => _NavigationScreenState();
}

class _NavigationScreenState extends State<NavigationScreen> {
  final List<Widget> screens = [
    ShoeListScreen(),
    FavouriteScreen(),
    FilterScreen(),
    ProfileScreen(),
  ];
  var pageIndex = 0;

  Widget buildIconButton(int currentIndex, IconData icon) {
    return IconButton(
      onPressed: () {
        setState(() {
          pageIndex = currentIndex;
        });
      },
      icon: Icon(
        icon,
        color: pageIndex == currentIndex
            ? Theme.of(context).accentColor
            : Colors.grey,
        size: 30,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuerData =
        MediaQuery.of(context).size.height - MediaQuery.of(context).padding.top;
    return Scaffold(
      extendBody: true,
      bottomNavigationBar: Container(
        height: mediaQuerData * .09,
        child: BottomBar(buildIconButton),
      ),
      drawer: DraweWid(),
      body: SingleChildScrollView(
        child: Column(
          children: [
            TopBar(pageIndex),
            screens[pageIndex],
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: Container(
        child: FittedBox(
          child: Stack(
            children: [
              Container(
                height: mediaQuerData * .08,
                width: mediaQuerData * .08,
                child: FloatingActionButton(
                  onPressed: () {
                    Navigator.of(context).pushNamed(CartScreen.routeName);
                  },
                  child: SvgPicture.asset(
                    'assets/images/cart.svg',
                    color: Theme.of(context).secondaryHeaderColor,
                    width: 25,
                  ),
                ),
              ),
              Positioned(
                right: 0,
                child: Container(
                  child: Center(
                    child: Text(
                      '${myCart.length}',
                      style: TextStyle(
                        color: Colors.white,
                      ),
                    ),
                  ),
                  padding: EdgeInsets.all(4),
                  constraints: BoxConstraints(minHeight: 25, minWidth: 25),
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                          spreadRadius: 1,
                          blurRadius: 5,
                          color: Colors.black.withAlpha(50))
                    ],
                    borderRadius: BorderRadius.circular(32),
                    color: Colors.red,
                    border: Border.all(color: Colors.white),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
