import 'package:flutter/material.dart';

import '../widgets/drawer_widget.dart';
import '../widgets/headline.dart';
import '../widgets/top_bar.dart';

class NotificationScreen extends StatelessWidget {
  static const routeName = 'NotificationScreen';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: DraweWid(),
      body: SafeArea(
        child: Column(
          children: [
            TopBar(4),
            Container(
              margin: EdgeInsets.only(top: 150),
              child: Column(
                children: [
                  Icon(Icons.notification_important_sharp,
                      color: Colors.grey.shade500),
                  Text(
                    'No Notifications',
                    style: TextStyle(color: Colors.grey.shade500),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
