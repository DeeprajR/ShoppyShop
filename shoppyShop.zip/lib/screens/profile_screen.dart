import 'dart:math';

import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  static const routeName = '/ProfileScreen';
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Container(
            height: 120,
            width: 120,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(55),
                boxShadow: [
                  BoxShadow(blurRadius: 40, color: Colors.black.withAlpha(50))
                ]),
            child: CircleAvatar(
                maxRadius: 55,
                foregroundImage: NetworkImage(
                    'https://rukminim1.flixcart.com/image/800/960/kkzrpu80/shirt/y/k/w/40-afzsh0039-arrow-original-imagy7weupuxnqdf.jpeg'),
                backgroundImage: AssetImage('assets/images/624A7739.JPG')),
          )
        ],
      ),
    );
  }
}
