import 'package:flutter/foundation.dart';

class Wearing {
  final String? id;
  final String? title;
  final int? price;
  final double? rating;
  final int? offerPercentage;
  final String? imageUrl;
  final List<String>? sizes;
  final String? descrption;
  final bool? isOfferAvilable;
  final bool? isPant;
  final bool? isShirt;
  final bool? isTshirt;
  final bool? isFullSlive;
  final bool? isHalfSleeve;
  final bool? isJean;
  final bool? isFormal;
  final bool? isPartyWearing;
  Wearing({
    @required this.id,
    @required this.title,
    @required this.price,
    @required this.rating,
    @required this.offerPercentage,
    @required this.imageUrl,
    @required this.sizes,
    @required this.descrption,
    @required this.isOfferAvilable,
    @required this.isPant,
    @required this.isShirt,
    @required this.isTshirt,
    @required this.isFullSlive,
    @required this.isHalfSleeve,
    @required this.isJean,
    @required this.isFormal,
    @required this.isPartyWearing,
  });
}
