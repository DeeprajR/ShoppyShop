import 'package:flutter/material.dart';

class FadeInImae extends StatelessWidget {
  final String giphy;
  final String? imageUrl;
  FadeInImae(this.giphy, this.imageUrl);
  @override
  Widget build(BuildContext context) {
    return FadeInImage.assetNetwork(
      placeholder: giphy,
      image: imageUrl ?? '',
      fit: BoxFit.cover,
    );
  }
}
