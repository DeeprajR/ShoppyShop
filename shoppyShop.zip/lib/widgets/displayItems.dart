import 'package:flutter/material.dart';

import '../screens/dress_details_screen.dart';

import './fade_in_image.dart';

class DisplayItems extends StatelessWidget {
  final List favFolder;
  DisplayItems(this.favFolder);

  @override
  Widget build(BuildContext context) {
    var meddata = MediaQuery.of(context).size.height;
    return favFolder.isEmpty
        ? Container(
            child: Container(
            margin: EdgeInsets.symmetric(horizontal: 50, vertical: 80),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  margin: EdgeInsets.all(30),
                  child: Column(
                    children: [
                      Text('You Dont Added Anything to Favourite Yet',
                          style:
                              TextStyle(fontFamily: 'Righteous', fontSize: 20)),
                      Text(
                        '(tap on fav button to Add)',
                        style: TextStyle(
                            color: Colors.grey, fontFamily: 'Righteous'),
                      ),
                    ],
                  ),
                ),
                Image.asset('assets/images/giphy(1).gif')
              ],
            ),
          ))
        : Container(
            height: meddata * .82,
            child: GridView.builder(
              gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                maxCrossAxisExtent: 300,
                childAspectRatio: 3 / 4.8,
                crossAxisSpacing: 20,
                mainAxisSpacing: 20,
              ),
              padding: EdgeInsets.all(15),
              itemCount: favFolder.length,
              itemBuilder: (ctx, item) {
                return LayoutBuilder(
                  builder: (ctx, constraints) {
                    return InkWell(
                      borderRadius: BorderRadius.circular(15),
                      splashColor: Theme.of(context).accentColor,
                      onTap: () {
                        Navigator.of(context).pushNamed(
                          DressDetailsScreen.routeName,
                          arguments: favFolder[item].id,
                        );
                      },
                      child: Card(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15)),
                        color: Colors.white,
                        elevation: 5,
                        child: Stack(
                          children: [
                            Column(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(15),
                                    topRight: Radius.circular(15),
                                  ),
                                  child: Container(
                                      height: constraints.maxHeight * .7,
                                      width: double.infinity,
                                      child: FadeInImae(
                                          'assets/images/giphy.gif',
                                          favFolder[item].imageUrl)),
                                ),
                                Container(
                                  height: constraints.maxHeight * .16,
                                  padding: EdgeInsets.only(
                                    top: 10,
                                    left: 15,
                                    right: 10,
                                  ),
                                  child: Text(
                                    favFolder[item].title ?? '',
                                    overflow: TextOverflow.fade,
                                    softWrap: true,
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13),
                                  ),
                                ),
                                Container(
                                  padding: EdgeInsets.symmetric(horizontal: 11),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          Icon(Icons.attach_money_rounded),
                                          Text('${favFolder[item].price}',
                                              style: TextStyle(
                                                  fontFamily: 'FredokaOne',
                                                  fontSize: 16))
                                        ],
                                      ),
                                      Container(
                                        height: constraints.maxHeight * .07,
                                        width: constraints.maxWidth * .19,
                                        child: FittedBox(
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons.star,
                                                color: Colors.amber,
                                              ),
                                              Text('${favFolder[item].rating}')
                                            ],
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                )
                              ],
                            ),
                            if (favFolder[item].isOfferAvilable == true)
                              Positioned(
                                top: 50,
                                child: Container(
                                  padding: EdgeInsets.all(5),
                                  height: 30,
                                  width: 60,
                                  decoration: BoxDecoration(
                                    color: Colors.red.withOpacity(.8),
                                    borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(10),
                                      bottomRight: Radius.circular(10),
                                    ),
                                  ),
                                  child: Center(
                                    child: Text(
                                      '${favFolder[item].offerPercentage}% Off',
                                      style: TextStyle(color: Colors.white),
                                    ),
                                  ),
                                ),
                              )
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          );
  }
}
