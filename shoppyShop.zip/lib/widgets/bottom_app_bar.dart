import 'package:flutter/material.dart';

class BottomBar extends StatelessWidget {
  final Function buildIconButton;
  BottomBar(this.buildIconButton);

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return BottomAppBar(
          elevation: 15,
          clipBehavior: Clip.antiAlias,
          shape: CircularNotchedRectangle(),
          notchMargin: constraints.maxHeight * .11,
          child: Container(
            height: constraints.maxHeight * .1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    SizedBox(
                      width: constraints.maxWidth * .03,
                    ),
                    buildIconButton(0, Icons.home_filled),
                    SizedBox(
                      width: constraints.maxWidth * .07,
                    ),
                    buildIconButton(1, Icons.favorite),
                  ],
                ),
                Row(
                  children: [
                    buildIconButton(2, Icons.notes_sharp),
                    SizedBox(
                      width: constraints.maxWidth * .07,
                    ),
                    buildIconButton(3, Icons.person),
                    SizedBox(
                      width: constraints.maxWidth * .03,
                    ),
                  ],
                )
              ],
            ),
          ),
        );
      },
    );
  }
}
