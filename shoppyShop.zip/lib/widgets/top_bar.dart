import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intl/intl.dart';

import './headline.dart';

class TopBar extends StatelessWidget {
  final int pageIndex;
  TopBar(this.pageIndex);
  String get headLine {
    String head = 'OurProduct';
    if (pageIndex == 0) {
      return head = 'OurProduct';
    } else if (pageIndex == 1) {
      return head = 'Your favorites';
    } else if (pageIndex == 2) {
      return head = 'Filter Products';
    } else if (pageIndex == 3) {
      return head = 'Profile';
    } else if (pageIndex == 4) {
      return head = 'Notifications';
    }
    return head;
  }

  @override
  Widget build(BuildContext context) {
    String time = DateFormat.yMd().format(DateTime.now());

    return Column(
      children: [
        Container(
          margin: EdgeInsets.only(
              left: 10, right: 10, top: MediaQuery.of(context).padding.top),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              InkWell(
                onTap: () {
                  Scaffold.of(context).openDrawer();
                },
                child: SvgPicture.asset(
                  'assets/images/menu.svg',
                ),
              ),
              Headline(),
              InkWell(
                  onTap: () {},
                  child: CircleAvatar(
                    radius: 20,
                    backgroundImage: AssetImage(
                      'assets/images/624A7739.JPG',
                    ),
                  )),
            ],
          ),
        ),
        Container(
          margin: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                headLine,
                style: Theme.of(context).textTheme.headline5,
              ),
              if (pageIndex == 0 || pageIndex == 1)
                InkWell(
                  onTap: () {},
                  child: Container(
                    child: Row(
                      children: [
                        Text(time),
                      ],
                    ),
                  ),
                )
            ],
          ),
        )
      ],
    );
  }
}
