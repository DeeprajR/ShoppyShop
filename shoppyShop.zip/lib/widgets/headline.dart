import 'package:flutter/material.dart';

class Headline extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          'Shoppy',
          style: Theme.of(context).textTheme.headline6,
        ),
        Text(
          'Shop',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
            fontFamily: 'ReggaeOne',
            color: Theme.of(context).secondaryHeaderColor,
          ),
        ),
      ],
    );
  }
}
