import 'package:flutter/material.dart';
import 'package:shoppy_shop/models/wearing_model.dart';

class Sizes extends StatelessWidget {
  final Wearing selectedItem;
  Sizes(this.selectedItem);
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 60,
      width: 400,
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.only(left: 15),
            width: 70,
            height: 60,
            child: Center(
              child: Text(
                'Sizes:',
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            ),
          ),
          Container(
            width: 300,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: selectedItem.sizes!.length,
              itemBuilder: (ctx, index) {
                return Container(
                  margin: EdgeInsets.all(15),
                  height: 10,
                  width: 50,
                  child: RawMaterialButton(
                    splashColor: Theme.of(context).secondaryHeaderColor,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15)),
                    onPressed: () {},
                    child: Text(
                      selectedItem.sizes![index],
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                          fontSize: 20),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
