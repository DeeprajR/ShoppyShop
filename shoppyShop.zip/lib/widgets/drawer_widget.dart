import 'package:flutter/material.dart';

import '../screens/notification_screen.dart';

class DraweWid extends StatelessWidget {
  Widget buildListtile(
      IconData icon, String title, BuildContext context, String routename) {
    return ListTile(
        leading: Icon(
          icon,
          size: 30,
        ),
        title: Text(
          title,
          style: Theme.of(context).textTheme.headline5,
        ),
        onTap: () {
          Navigator.of(context).pushReplacementNamed(routename);
        });
  }

  @override
  Widget build(BuildContext context) {
    final mediadata = MediaQuery.of(context).size;
    return Container(
      height: mediadata.height,
      width: mediadata.width * .7,
      color: Colors.white,
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Theme.of(context).accentColor,
                  Theme.of(context).accentColor.withOpacity(.7),
                ],
                begin: Alignment.bottomRight,
                end: Alignment.centerLeft,
              ),
            ),
            padding: EdgeInsets.only(
              top: MediaQuery.of(context).padding.top,
            ),
            height: mediadata.height * .35,
            width: double.infinity,
            alignment: Alignment.centerLeft,
            child: Container(
              margin: EdgeInsets.all(20),
              child: Text(
                'HappyShoppy!',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 30,
                ),
              ),
            ),
          ),
          SizedBox(
            height: mediadata.height * .05,
          ),
          buildListtile(Icons.category, 'Category', context, '/'),
          buildListtile(Icons.notifications, 'Notifications', context,
              NotificationScreen.routeName),
        ],
      ),
    );
  }
}
